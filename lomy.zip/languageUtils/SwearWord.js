//Node.js 10.14.0
//Plain Javascript and Node.js is supported
// html/css is not supported here 

class SwearWord {
  constructor(fileName) {
    this.fileName = fileName;
  }
}

module.exports = SwearWord;